# nimbls visual library

PNG: slides and documents. SVG: editable vector artwork. Markdown: presentation notes. Keep planned-capability and reconstruction labels. The roadmap poster is undated; use the full website planner for dated exports.

Provider mark sources and reuse context: assets/nimbls-architecture.md.
